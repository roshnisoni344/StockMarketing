package com.cognizant.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Company  {
	
	
	@Id

	private int stockCodeInEachStock;
	private String companyName;
	private double turnOver;
	private String CEO;
	private String boardOfDirectors;
	private String listedInStockExchange;
	private String sectorName;
	private String briefWriteUp;
	
	
	public int getStockCodeInEachStock() {
		return stockCodeInEachStock;
	}
	public void setStockCodeInEachStock(int stockCodeInEachStock) {
		this.stockCodeInEachStock = stockCodeInEachStock;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public double getTurnOver() {
		return turnOver;
	}
	public void setTurnOver(double turnOver) {
		this.turnOver = turnOver;
	}
	public String getCEO() {
		return CEO;
	}
	public void setCEO(String cEO) {
		CEO = cEO;
	}
	public String getBoardOfDirectors() {
		return boardOfDirectors;
	}
	public void setBoardOfDirectors(String boardOfDirectors) {
		this.boardOfDirectors = boardOfDirectors;
	}
	public String getListedInStockExchange() {
		return listedInStockExchange;
	}
	public void setListedInStockExchange(String listedInStockExchange) {
		this.listedInStockExchange = listedInStockExchange;
	}
	public String getSector() {
		return sectorName;
	}
	public void setSector(String sector) {
		this.sectorName = sector;
	}
	public String getBriefWriteUp() {
		return briefWriteUp;
	}
	public void setBriefWriteUp(String briefWriteUp) {
		this.briefWriteUp = briefWriteUp;
	}
	@Override
	public String toString() {
		return "Company [stockCodeInEachStock=" + stockCodeInEachStock + ", companyName=" + companyName + ", turnOver="
				+ turnOver + ", CEO=" + CEO + ", boardOfDirectors=" + boardOfDirectors + ", listedInStockExchange="
				+ listedInStockExchange + ", sector=" + sectorName + ", briefWriteUp=" + briefWriteUp + "]";
	}
	

}



